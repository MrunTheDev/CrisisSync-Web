import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import { getAuth, signInAnonymously } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";
import {
    getFirestore,
    collection,
    addDoc,
    doc,
    onSnapshot,
    serverTimestamp
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";

/* -----------------------------
   1. BACKEND URL
------------------------------ */

const BASE_URL = "https://YOUR-APP.up.railway.app";

/* -----------------------------
   2. FIREBASE CONFIG
------------------------------ */

const firebaseConfig = {
    apiKey: "AIzaSyAD5cXsGGWzzi7yQnz1nfZcYmfrDZmv--4",
    authDomain: "crisissync-gdg.firebaseapp.com",
    projectId: "crisissync-gdg",
    storageBucket: "crisissync-gdg.firebasestorage.app",
    messagingSenderId: "105702461886",
    appId: "1:105702461886:web:3c9541193e0c93c2a6a9ef",
    measurementId: "G-YB3SXBP4XN"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

/* -----------------------------
   3. GLOBAL STATE
------------------------------ */

let selectedType = "MEDICAL";
let unsubscribeFn = null;

/* -----------------------------
   4. LOADER + START QR SCANNER
------------------------------ */

window.addEventListener("load", () => {
    setTimeout(() => {
        document.getElementById("loader").classList.add("fade-out");

        const g0 = document.getElementById("g0");
        const g1 = document.getElementById("g1");

        // Show QR scan page first
        if (g0) g0.style.display = "flex";
        if (g1) g1.style.display = "none";

        startQRScanner();

    }, 700);
});

/* -----------------------------
   5. QR CODE SCANNER
------------------------------ */

function startQRScanner() {
    const reader = document.getElementById("reader");

    if (!reader) return;

    function onScanSuccess(decodedText) {
        console.log("QR Code scanned:", decodedText);

        // Stop scanner after successful scan
        html5QrCode.stop().then(() => {
            console.log("Scanner stopped");
        }).catch(err => {
            console.log("Stop failed:", err);
        });

        // Auto-fill location field
        const locInput = document.getElementById("loc");
        if (locInput) {
            locInput.value = decodedText;
        }

        // Move to SOS page
        document.getElementById("g0").style.display = "none";
        document.getElementById("g1").style.display = "flex";
    }

    const html5QrCode = new Html5Qrcode("reader");

    Html5Qrcode.getCameras()
        .then(devices => {
            if (devices && devices.length) {
                html5QrCode.start(
                    devices[0].id,
                    {
                        fps: 10,
                        qrbox: 250
                    },
                    onScanSuccess
                );
            } else {
                alert("No camera found.");
            }
        })
        .catch(err => {
            console.error("Camera error:", err);
            alert("Camera permission denied or camera not found.");
        });
}

/* -----------------------------
   6. EMERGENCY TYPE SELECT
------------------------------ */

window.pickType = function (btn) {
    document.querySelectorAll(".type-chip").forEach(chip => {
        chip.classList.remove("active");
    });

    btn.classList.add("active");
    selectedType = btn.dataset.type;
};

/* -----------------------------
   7. SEND SOS
------------------------------ */

window.handleSOS = async function () {
    const siren = document.getElementById("siren-sound");
    if (siren) {
        siren.loop = true; // Keeps the siren going
        siren.play().catch(err => console.warn("Audio play blocked by browser:", err));
    }
    const locEl = document.getElementById("loc");
    const location = locEl.value.trim() || "Location not specified";

    const btn = document.getElementById("sos-btn");

    // 1. Update button text directly since there are no internal spans
    btn.disabled = true;
    btn.textContent = "Connecting...";

    // 2. Immediately show the success page to the user
    goToSuccessPage();

    // 3. Process the backend logic
    try {
        await signInAnonymously(auth);

        const docRef = await addDoc(collection(db, "incidents"), {
            type: selectedType,
            location: location,
            description: "",
            status: "PENDING",
            hotelId: "hotel-demo",
            createdAt: serverTimestamp()
        });

        const incidentId = docRef.id;

        fetch(`${BASE_URL}/triage`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                incidentId: incidentId,
                type: selectedType,
                location: location,
                description: "",
                hotelId: "hotel-demo"
            })
        }).catch(err => {
            console.warn("Triage POST failed:", err.message);
        });

        listenForTriage(incidentId);

        // Fallback fake triage for testing UI
        setTimeout(() => {
            const spinWrap = document.getElementById("spin-wrap");

            if (spinWrap && spinWrap.style.display !== "none") {
                renderTriage({
                    severity: "ACTIVE",
                    guest_message: "Staff are reviewing your request now.",
                    eta_minutes: 5,
                    action_steps: [
                        "Remain calm",
                        "Stay in your current location"
                    ]
                });
            }
        }, 5000);

    } catch (err) {
        // If Firebase fails, alert the user and reset the button
        alert("Could not send SOS to database: " + err.message);
        
        // Reset button
        btn.disabled = false;
        btn.textContent = "SOS";
        
        // Optionally switch back to the SOS page if it fails entirely
        document.getElementById("g2").style.display = "none";
        document.getElementById("g1").style.display = "flex";
    }
};
/*
   8. PAGE SWITCH
------------------------------ */

function goToSuccessPage() {
    document.getElementById("g1").style.display = "none";
    document.getElementById("g2").style.display = "flex";
}

/* -----------------------------
   9. FIRESTORE LISTENER
------------------------------ */

function listenForTriage(incidentId) {
    const ref = doc(db, "incidents", incidentId);

    unsubscribeFn = onSnapshot(ref, (snap) => {
        if (!snap.exists()) return;

        const data = snap.data();

        if (data.triageError) {
            hideSpinner();
            document.getElementById("err-card").style.display = "block";
            cleanupListener();
            return;
        }

        if (data.triage) {
            renderTriage(data.triage);
            cleanupListener();
        }
    });
}

/* -----------------------------
   10. RENDER TRIAGE
------------------------------ */

function renderTriage(triage) {
    document.getElementById("guest-msg").textContent =
        triage.guest_message || "Our team is responding.";

    document.getElementById("wait-sub").textContent =
        triage.guest_message || "Our team is responding.";

    const severityTag = document.getElementById("sev-tag");
    severityTag.textContent = triage.severity || "ACTIVE";
    severityTag.className = `sev-tag sev-${triage.severity}`;

    document.getElementById("eta-num").textContent =
        triage.eta_minutes ?? "—";

    const list = document.getElementById("action-list");
    list.innerHTML = "";

    if (triage.action_steps) {
        triage.action_steps.forEach((step, index) => {
            const li = document.createElement("li");
            li.className = "action-item";

            li.innerHTML = `
                <span class="action-num">${index + 1}</span>
                <span>${step}</span>
            `;

            list.appendChild(li);
        });
    }

    if (triage.escalate_to_112) {
        const callout = document.getElementById("callout-112");
        if (callout) {
            callout.style.display = "flex";
        }
    }

    hideSpinner();
    document.getElementById("triage-card").style.display = "flex";
}

/* -----------------------------
   11. HELPERS
------------------------------ */

function hideSpinner() {
    const spinWrap = document.getElementById("spin-wrap");
    if (spinWrap) {
        spinWrap.style.display = "none";
    }
}

function cleanupListener() {
    if (unsubscribeFn) {
        unsubscribeFn();
        unsubscribeFn = null;
    }
}

/* -----------------------------
   12. SKIP SCAN BUTTON
------------------------------ */

window.skipScan = function () {
    const g0 = document.getElementById("g0");
    const g1 = document.getElementById("g1");

    if (g0) g0.style.display = "none";
    if (g1) g1.style.display = "flex";
};
window.previewImage = function(input) {
    const placeholder = document.getElementById('upload-placeholder');
    const preview = document.getElementById('image-preview');
    
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = function(e) {
            preview.src = e.target.result;
            preview.style.display = 'block';
            placeholder.style.display = 'none';
        }
        reader.readAsDataURL(input.files[0]);
    }
}
/* -----------------------------
   13. LOADER & INITIAL SCREEN
------------------------------ */

window.addEventListener("load", () => {
    setTimeout(() => {
        // Hide the loading screen
        document.getElementById("loader").classList.add("fade-out");

        // RESET: Hide all pages first
        document.getElementById("g0").style.display = "none";
        document.getElementById("g1").style.display = "none";
        document.getElementById("g2").style.display = "none";
        
        // SHOW: Only the Role Selection screen
        const roleSel = document.getElementById("role-sel");
        if (roleSel) roleSel.style.display = "flex";

    }, 700);
});

/* -----------------------------
   14. ROLE ROUTING LOGIC
------------------------------ */

window.chooseRole = function(role) {
    const roleSel = document.getElementById("role-sel");
    const g0 = document.getElementById("g0");

    // Hide the selection screen
    if (roleSel) roleSel.style.display = "none";

    if (role === 'guest') {
        // Go to QR Scan page
        if (g0) g0.style.display = "flex";
        // Start the scanner only now
        startQRScanner(); 
    } else if (role === 'staff') {
        alert("Redirecting to Staff Live Feed...");
        // This is where you will link your Staff Dashboard later
    } else if (role === 'admin') {
        alert("Opening Global Impact Dashboard...");
        // This is where you will link your Admin/Public page later
    }
};