import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import { getAuth, signInAnonymously } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";
import { getFirestore, collection, addDoc, doc, onSnapshot, serverTimestamp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";

// ─── 1. BASE URL ─────────────────────────────────────────────
const BASE_URL = "https://YOUR-APP.up.railway.app"; // Update this!

// ─── 2. FIREBASE CONFIG ──────────────────────────────────────
const firebaseConfig = {
    apiKey: "AIzaSyAD5cXsGGWzzi7yQnz1nfZcYmfrDZmv--4",
    authDomain: "crisissync-gdg.firebaseapp.com",
    projectId: "crisissync-gdg",
    storageBucket: "crisissync-gdg.firebasestorage.app",
    messagingSenderId: "105702461886",
    appId: "1:105702461886:web:3c9541193e0c93c2a6a9ef",
    measurementId: "G-YB3SXBP4XN",
};

const fbApp = initializeApp(firebaseConfig);
const auth = getAuth(fbApp);
const db = getFirestore(fbApp);

// ─── 3. UI STATE & INITIALIZATION ─────────────────────────────
let selectedType = "MEDICAL";
let unsubscribeFn = null;

window.addEventListener("load", () => {
    setTimeout(() => document.getElementById("loader").classList.add("fade-out"), 700);
});

// ─── 4. GLOBAL FUNCTIONS ─────────────────────────────────────
// Attached to window so inline onclick handlers in HTML can find them
window.pickType = function(btn) {
    document.querySelectorAll(".type-chip").forEach(c => c.classList.remove("active"));
    btn.classList.add("active");
    selectedType = btn.dataset.type;
};

window.handleSOS = async function() {
    const locEl = document.getElementById("loc");
    const location = locEl.value.trim() || "Location not specified";
    const btn = document.getElementById("sos-btn");

    btn.disabled = true;
    btn.querySelector(".btn-label").textContent = "···";
    btn.querySelector(".btn-sub").textContent = "Connecting";

    try {
        await signInAnonymously(auth);
        
        const docRef = await addDoc(collection(db, "incidents"), {
            type: selectedType,
            location: location,
            description: "",
            status: "PENDING",
            hotelId: "hotel-demo",
            createdAt: serverTimestamp(),
        });

        const incidentId = docRef.id;

        fetch(`${BASE_URL}/triage`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                incidentId: incidentId,
                type: selectedType,
                location: location,
                description: "",
                hotelId: "hotel-demo",
            }),
        }).catch(e => console.warn("Triage POST failed:", e.message));

        goToG2();
        listenForTriage(incidentId);

    } catch (err) {
        btn.disabled = false;
        btn.querySelector(".btn-label").textContent = "SOS";
        alert(`Could not send SOS: ${err.message}`);
    }
};

// ─── 5. LOGIC HELPERS ────────────────────────────────────────
function goToG2() {
    document.getElementById("g1").style.display = "none";
    document.getElementById("g2").style.display = "flex";
}

function listenForTriage(incidentId) {
    const ref = doc(db, "incidents", incidentId);
    unsubscribeFn = onSnapshot(ref, (snap) => {
        if (!snap.exists()) return;
        const data = snap.data();

        if (data.triageError) {
            hideSpin();
            document.getElementById("err-card").style.display = "block";
            cleanupListener();
            return;
        }

        if (data.triage) {
            renderTriage(data.triage);
            cleanupListener();
        }
    });
}

function renderTriage(t) {
    document.getElementById("guest-msg").textContent = t.guest_message || "Our team is responding.";
    document.getElementById("wait-sub").textContent = t.guest_message || "Our team is responding.";
    
    const tag = document.getElementById("sev-tag");
    tag.textContent = t.severity || "ACTIVE";
    tag.className = `sev-tag sev-${t.severity}`;

    document.getElementById("eta-num").textContent = t.eta_minutes ?? "—";

    const list = document.getElementById("action-list");
    list.innerHTML = "";
    if (t.action_steps) {
        t.action_steps.forEach((step, i) => {
            const li = document.createElement("li");
            li.className = "action-item";
            li.innerHTML = `<span class="action-num">${i + 1}</span><span>${step}</span>`;
            list.appendChild(li);
        });
    }

    if (t.escalate_to_112) document.getElementById("callout-112").style.display = "flex";

    hideSpin();
    document.getElementById("triage-card").style.display = "flex";
}

function hideSpin() { document.getElementById("spin-wrap").style.display = "none"; }
function cleanupListener() { if (unsubscribeFn) { unsubscribeFn(); unsubscribeFn = null; } }
// Add this inside handleSOS after calling listenForTriage(incidentId);
setTimeout(() => {
  // If AI takes too long, just show a default message so it's not stuck
  if (document.getElementById("spin-wrap").style.display !== "none") {
    renderTriage({
      severity: "ACTIVE",
      guest_message: "Staff are reviewing your request now.",
      eta_minutes: 5,
      action_steps: ["Remain calm", "Stay in your current location"]
    });
  }
}, 5000); // After 5 seconds, show a default result
// --- QR SCANNER LOGIC ---
let html5QrCode;

window.addEventListener("load", () => {
    // Start scanner on load
    startScanner();
});

function startScanner() {
    html5QrCode = new Html5Qrcode("reader");
    const config = { fps: 10, qrbox: { width: 250, height: 250 } };

    html5QrCode.start(
        { facingMode: "environment" }, 
        config,
        (decodedText) => {
            try {
                // Assuming QR contains: {"hotelId": "hotel-demo", "room": "Room 412", "floor": "4"}
                const data = JSON.parse(decodedText);
                
                // 1. Auto-fill the location input
                document.getElementById("loc").value = `${data.room} (Floor ${data.floor})`;
                
                // 2. Stop camera and move to SOS screen
                stopScannerAndGo();
            } catch (e) {
                console.error("Invalid QR Format. Ensure it is JSON.");
            }
        }
    ).catch(err => console.error("Camera access denied", err));
}

function stopScannerAndGo() {
    if (html5QrCode) {
        html5QrCode.stop().then(() => {
            document.getElementById("g0").style.display = "none";
            document.getElementById("g1").style.display = "flex";
        });
    }
}

function skipScan() {
    stopScannerAndGo();
}
// This connects your module code to the HTML buttons
window.skipScan = skipScan;
window.handleSOS = handleSOS; 
window.pickType = pickType;